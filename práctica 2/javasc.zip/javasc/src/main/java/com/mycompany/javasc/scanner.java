package com.mycompany.javasc;

public class scanner {
}
