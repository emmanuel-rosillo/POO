package com.mycompany.javasc;

public class vars {
    public static int suma(int var1, int var2) {
        int a;
        a = var1 + var2;
        System.out.println(a);
        return (a);
    }
    public static boolean resta(int g, int g3) {
        int a;
        a = g - g3;
        if (a == 1000){
            return true;
        }
        else {
            return false;
        }

    }


}